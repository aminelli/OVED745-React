export default function Container({ children }) {
  return <section className="bg-body-secondary">{children}</section>;
}
