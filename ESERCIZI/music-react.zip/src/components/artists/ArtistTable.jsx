import Container from "../Container";
import SubTitle from "../static/SubTitle";

export default function ArtistTable({ artists = [], onDelete }) {
  const text = "Lista degli Artisti";

  return (
    <Container>
      <div className="table-responsive">
        <SubTitle text={text} />
        <table className="table table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Nome</th>
              <th>Genere</th>
              <th>Nazione</th>
              <th>Inizio attività</th>
              <th>Azioni</th>
            </tr>
          </thead>
          <tbody>
            {artists.map((artist, index) => (
              <tr key={artist.id}>
                <td>{index + 1}</td>
                <td>{artist.name}</td>
                <td>{artist.genre}</td>
                <td>{artist.country}</td>
                <td>{artist.activeSince}</td>
                <td>
                  <button
                    type="button"
                    className="btn btn-danger btn-sm"
                    onClick={() => onDelete(artist)}
                  >
                    Elimina
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Container>
  );
}
