import { useEffect, useState } from "react";
import ArtistTable from "./ArtistTable";
import { deleteArtist, fetchArtists } from "../../api/artists";

export default function ArtistPage() {
  // Simulo il comportamento di una Promise
  const [loading, setLoading] = useState(true); // pending
  const [artists, setArtists] = useState([]); // fullfill
  const [error, setError] = useState(null); // reject

  useEffect(() => {
    const loadArtists = async () => {
      setLoading(true);
      setError(null);

      try {
        const responseBody = await fetchArtists();
        setArtists(responseBody);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadArtists();

    return () => {
      console.log(
        "Operazioni finali poco dopo lo smontaggio e prima della rimozione del componente",
      );
    };
  }, []);

  const handleDelete = async (artist) => {
    const confirmed = confirm(`Vuoi eliminare l'Artista ${artist.name}?`);

    if (!confirmed) {
      return;
    }

    try {
      await deleteArtist(artist.id);

      setArtists((prevState) =>
        prevState.filter((item) => item.id !== artist.id),
      );
    } catch (err) {
      setError(err.message);
    }
  };

  if (error) {
    return <p>Errore! {error}</p>;
  }

  return loading ? (
    <p>Caricamento...</p>
  ) : (
    <section>
      <ArtistTable artists={artists} onDelete={handleDelete} />
    </section>
  );
}
