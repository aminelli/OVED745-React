export default function SubTitle({ text }) {
  return <h2 className="text-center">{text}</h2>;
}
