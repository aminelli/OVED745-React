const API_BASE = "http://localhost:3001/artists";

async function request(url, options = {}) {
  const response = await fetch(url, options);

  if (!response.ok) {
    throw new Error(`Errore ${response.status}`);
  }

  return response.json();
}

// CREATE
export function createArtist(artist) {}

// READ
export function fetchArtist(id) {}

// UPDATE
export function updateArtist(id, artist) {}

// DELETE
export function deleteArtist(id) {
  return request(`${API_BASE}/${id}`, {
    method: "DELETE",
  });
}

// GET
export function fetchArtists() {
  return request(API_BASE);
}
