import ArtistPage from "./components/artists/ArtistPage";

function App() {
  return (
    <>
      <h1 className="text-center">Music</h1>
      <main className="container">
        <ArtistPage />
      </main>
    </>
  );
}

export default App;
